
    <?php 
    header("URL=PagodaDirectory/index.php")
?>