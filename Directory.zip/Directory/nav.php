
<div class="container-fluid mb-3">
        <div class="row border-top px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn shadow-none d-flex align-items-center justify-content-between text-white w-100" style="background-color:#154360;" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
                <h6 class="m-0"><font color=" #27AE60">တိုင်းဒေသကြီး/ပြည်နယ် </font></h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                    <div class="navbar-nav w-100 overflow-hidden" style="height: 615px;background-color:#f8fcee">
                            <a href="Yangon.php" class="nav-item nav-link list-group-item list-group-item-action list-group-item-primary">ရန်ကုန်တိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-success">မန္တလေးတိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-secondary">နေပြည်တော်</a>
                            <a href="Bago.php" class="nav-item nav-link list-group-item list-group-item-action list-group-item-danger">ပဲခူးတိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-warning">မကွေးတိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-info">စစ်ကိုင်းတိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-light">ဧရာဝတီတိုင်းဒေသကြီး</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-dark">တနင်္သာာရီတိုင်းဒေသကြီး</a>                           
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-success">ကချင်ပြည်နယ် </a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-secondary">ကယားပြည်နယ်</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-primary">ကရင်ပြည်နယ်</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-warning">ချင်းပြည်နယ်</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-danger">မွန်ပြည်နယ်</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-info">ရခိုင်ပြည်နယ်</a>
                            <a href="" class="nav-item nav-link list-group-item list-group-item-action list-group-item-light">ရှမ်းပြည်နယ်</a> 
                                                                           
                    </div>
                </nav>
            </div>
            <div class="col-lg-9 mt-3">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!-- <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.php" class="nav-item nav-link active"><font color="#154360"><b>ပင်မစာမျက်နှာ</b></font></a>
                           
                            <a href="contact.php" class="nav-item nav-link"><font color="#154360"><b>ဆက်သွယ်ရန်</b></font></a>
                        </div>
                        
                    </div> -->
                </nav>
                <div id="header-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active" style="height: 600px;">
                            <img class="img-fluid" src="Directory/img/3.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">This is the directory for</h4>
                                    <h4 class="display-4 text-white font-weight-semi-bold mb-4">Famous Pagodas in Myanmar</h4>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item" style="height: 600px;">
                            <img class="img-fluid" src="Directory/img/2.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">This is the directory for</h4>
                                    <h4 class="display-4 text-white font-weight-semi-bold mb-4">Famous Pagodas in Myanmar</h4>                                    
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item" style="height: 600px;">
                            <img class="img-fluid" src="Directory/img/6.jpeg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">This is the directory for</h4>
                                    <h4 class="display-4 text-white font-weight-semi-bold mb-4">Famous Pagodas in Myanmar</h4>                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-prev-icon mb-n2"></span>
                        </div>
                    </a>
                    <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-next-icon mb-n2"></span>
                        </div>
                    </a>
                    
                </div>
            </div>
        </div>
    </div>