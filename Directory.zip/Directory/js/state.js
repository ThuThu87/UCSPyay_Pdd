// note that : replace your data in state array or update array for your design
const states = [
  {
    id: "s-1",
    name: "Chin",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-2",
    name: "Kachin",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-3",
    name: "Kayin (Karen)",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-4",
    name: "Kayah",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-5",
    name: "Mon",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-6",
    name: "Rakhine (Arakan)",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-7",
    name: "Shan",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-8",
    name: "Ayeyarwady (Irrawaddy),",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-9",
    name: "Magway (Magwe)",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-10",
    name: "Mandalay",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-11",
    name: "Bago (Pegu)",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-12",
    name: "Sagaing",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-13",
    name: "Taninthary (Tenasserim)",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
  {
    id: "s-14",
    name: "Yangon",
    cardText: `This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.`,
    cardImg: "./asset/images/s1.png",
  },
];

const cardContainer = document.getElementById("option");

//THis script looping is render in Home.html , in option UI

for (let i = 0; i < states.length; i++) {
  const options = document.createElement("div");
  options.classList.add("col-12", "col-md-8", "col-lg-5");
  options.innerHTML = `
      <div class="card mb-3 p-3 shadow shadow">
      <div class="row g-0">
        <div class="col-md-4 d-flex justify-content-center">
          <img
            src=${states[i].cardImg}
            class="img-fluid"
            alt="Img"
            style="height: 200px; width: 100%; object-fit: contain"
          />
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <h5 class="card-title">${states[i].name}</h5>
            <p class="card-text">
              ${states[i].cardText}
            </p>
            <a href="Option.html" class="btn btn-primary">SEE MORE</a>
          </div>
        </div>
      </div>
    </div>
      `;
  //   options.innerHTML = "Helo";
  cardContainer.append(options);
}
