const bodytag = document.getElementsByTagName("body")[0];

//Creat a button
const themeToggleBtn = document.createElement("div");
themeToggleBtn.setAttribute("title", "Click for change theme");
themeToggleBtn.style.width = "30px";
themeToggleBtn.style.bottom = "6px";
themeToggleBtn.style.right = "6px";
themeToggleBtn.style.position = "fixed";
themeToggleBtn.classList.add("btn", "btn-primary", "border", "p-0");
themeToggleBtn.innerHTML = `
    <img src="./asset/images/night-mode.png" class="w-100" alt="img" />
`;

//Append in body
bodytag.append(themeToggleBtn);

//Creat and ckeck theme
if (localStorage.getItem("theme") === "dark") {
  bodytag.setAttribute("data-bs-theme", "dark");
} else {
  bodytag.setAttribute("data-bs-theme", "light");
}

themeToggleBtn.addEventListener("click", () => {
  if (localStorage.getItem("theme") === "dark") {
    localStorage.setItem("theme", "light");
    bodytag.setAttribute("data-bs-theme", "light");
  } else {
    localStorage.setItem("theme", "dark");
    bodytag.setAttribute("data-bs-theme", "dark");
  }
});
