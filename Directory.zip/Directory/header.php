 <!-- Topbar Start -->
 
 <div class="container-fluid" >
        <div class="row py-2 px-xl-5" style="background-color:#27AE60">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="font-weight-bold px-3 mr-1"><font color="#154360"> Pagoda Digital Directory</font></h1> 
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <form action="">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="ရှာဖွေရန်">
                            <div class="input-group-append">
                                <span class="input-group-text bg-transparent">
                                <font color=" #154360"><i class="fa fa-search"></i>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Topbar End -->